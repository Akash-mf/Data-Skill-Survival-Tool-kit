USE ExploreCal_DB
GO

SELECT [Booked Tour Name]
      ,[Booking Date]
      ,[Tour Date]
      ,[Booking ID#]
      ,[# of Members]
      ,[Return Date]
      ,[Total Price for Party]
      ,[Booked In Days]
	  ,CASE	
			WHEN  [Booked in Days] <= 7 THEN 'Under 7' 
			WHEN [Booked in Days] > 7 AND [Booked in Days] <= 30  THEN 'Under 30'  
			WHEN [Booked in Days] > 30 AND [Booked in Days] <= 60 THEN 'Under 60' 
			WHEN [Booked in Days] > 60 AND [Booked in Days] <= 90 THEN 'Under 90'
			WHEN [Booked in Days] > 90 AND [Booked in Days] <= 180 THEN 'Under 180'
			WHEN [Booked in Days] > 180 THEN 'Over 180' 
		END AS BookingClass
	,CASE 
			WHEN [Booked in Days] <= 45  THEN '0-45 days'
			WHEN [Booked in Days] >= 46  AND [Booked in Days] <= 90  THEN '46-90 day'
			WHEN [Booked in Days] >= 91 AND [Booked in Days] <= 180  THEN '91-180 days'
			WHEN [Booked in Days] > 180 THEN '180+ days'
		END AS BookedBand
	
  FROM [tblTourBookings]
  ORDER BY [Booked In Days]