USE ExploreCal_DB
GO

SELECT [Booked Tour Name]
      ,[Booking Date]
      ,[Tour Date]
      ,[Booking ID#]
      ,[# of Members]
      ,[Return Date]
      ,[Total Price for Party]
      ,[Booked In Days]

	
  FROM [tblTourBookings]
  ORDER BY [Booked In Days]