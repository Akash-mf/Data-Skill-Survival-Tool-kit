
--Sample script that creates a database with all the defaults settings

Create Database ExploreCal_DB