--Use this script to create your database in the SQL Tool of your choice

CREATE DATABASE LM_Data

--Use the excercise files in the folder to import the individual data sets to your newly created db