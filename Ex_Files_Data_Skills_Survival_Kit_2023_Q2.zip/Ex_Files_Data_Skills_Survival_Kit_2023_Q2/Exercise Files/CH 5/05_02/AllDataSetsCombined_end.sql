SELECT * FROM dbo.Orders_PopUpShopZone4_Begin
UNION
SELECT * FROM dbo.Orders_PopUpShopZone5_Begin
UNION
SELECT * FROM dbo.Orders_PopUpShopZone6_Begin
UNION
SELECT * FROM dbo.Orders_PopUpShopZone7_Begin

